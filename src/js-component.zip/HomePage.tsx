import React from "react";
import {StatusTab, SubsBtn} from "./Utils"

interface HomePageProps {
  status: {
    cn: boolean;
    rs: boolean;
  }
  show: string;
}

export default class HomePage extends React.Component<HomePageProps, {}> {

  render() {
    let {cn, rs} = this.props.status
    let style = {
      display: this.props.show.toLowerCase() === "home" ? "initial" : "none"
    }
    return (
      <div
        id="page-root"
        className="row"
        style={style}
        {...{home: ""}}
      >

        <table className="status-ctn">

          <tbody>
            {/* <StatusTab
              titleText="Ready State"
              state={rs}
            />

            <StatusTab
              titleText="Connection"
              state={cn}
              stateText={{onTrue: "online", onFalse: "offline"}}
            /> */}

          </tbody>

        </table>

        <div className="sub-keys">
          <table><tbody><tr>
            {
              ["endpoint", "auth", "p256dh"]
              .map((i) => {
                return (<SubsBtn key={i} type={i} />)
              })
            }
          </tr></tbody></table>
        </div>
      </div>
    )
  }
}