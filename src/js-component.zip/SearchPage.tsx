import React from "react";
import {TeamCard} from "./Utils";

interface SearchPageState {
  elOptions: JSX.Element[];
  teamCards: JSX.Element[];
}

interface SearchPageProps {
  cn: boolean;
  show: string;
}

export default class SearchPage extends React.Component<SearchPageProps, SearchPageState> {
  state: SearchPageState = {
    elOptions: [],
    teamCards: []
  }

  errorEl: HTMLDivElement;

  requestArea(e: React.ChangeEvent<HTMLSelectElement>) {
    const load = goal.loading;

    goal.attachError(this.errorEl, { remove: true, hasHideClass: true });
    goal.request("area", {
      area: +e.target.value,
      showLoading: true
    })
    .then( res => res.json())
    .then( (_: FBOrg.SearchTeamsRegion) => {
      this.setState({teamCards: []});
      let cards: JSX.Element[] = [];
      for(let k of _.teams) {
        let card = <TeamCard key={k.id} team={k} liked={false}/>
        cards.push(card);
      }
      return cards;
    })
    .then( (cards) => {
      goal.request("trax", async (db) => {
        let all: FBOrg.Team[] = await db.getAll();
        if(all.length !== 0) {
          for(let k of all) {
            let idx = cards.findIndex(i => (+i.key) === k.id);
            cards[idx] = <TeamCard key={k.id} team={k} liked={true}/>
          }
        }
        this.setState({teamCards: cards});
      });
    })
    .then(_ => {
      setTimeout(() => load.show(), 550)
    })
    .catch(err => {
      goal.attachError(this.errorEl, {
        hasHideClass: true,
        text: "It seems you are offline."
      });
      setTimeout(() => load.show(), 550)
      throw err;
    })
  }

  componentDidUpdate(oldP: SearchPageProps) {
    const pr = this.props;
    if(pr.cn !== oldP.cn) {
      goal.attachError(this.errorEl, {
        remove: pr.cn,
        hasHideClass: true,
        text: "It seems you are offline."
      });
    }
  }

  componentDidMount() {
    let t = setInterval(() => {

      goal.request("trax", {storeName: "area"}, async (db) => {
        let all: FBOrg.Area[] = await db.getAll();

        if(all.length !== 0) {
          let opt = [];
          for(let k of all) {
            opt.push(<option key={k.id} value={k.id}>{k.name}</option>)
            goal.Areas = goal.Areas || {};
            goal.Areas[k.id] = k.name;
          }
          this.setState({ elOptions: opt })
          clearInterval(t);
        }
      });
    }, 100);

  }

  render() {
    let showed = this.props.show === "search"

    return (
      <div
        id="page-root"
        className={"row" + showed? "" : " hide"}
        {...{search: ""}}
      >

        <div className="find col s12">

          <select
            className="browser-default"
            onChange={this.requestArea.bind(this)}
            disabled={!this.props.cn}
            defaultValue="choose"
          >
            <option value="choose" disabled>Choose Search Area</option>
            {this.state.elOptions}
          </select>

          <div
            id="error"
            className="hide"
            ref={(el) => this.errorEl = el}
          >
          </div>

        </div>

      <div {...{field:"results"}} className="col s12">
        {this.state.teamCards}
      </div>

      </div>
    )
  }
}
