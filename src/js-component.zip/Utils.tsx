import React, {useEffect, useState} from "react";


export function IndexNavBtn(props: { page: string, selected: string }) {
  let {page, selected} = props;
  let icon = goal.icons[props.page];

  return (
    <li>
      <a
        href={"#"+page}
        className={selected === page ? "selected" : null}
        onClick={() => goal.emit("page.changed", page)}
      >
        <i className="material-icons">{icon}</i>
      </a>
    </li>
  );
};

export function SquadCard(props: {Player: FBOrg.Player}) {
  let p = props.Player
  let get = /^(\d+-\d+-\d+)/.exec(p.dateOfBirth);
  let birth = p.countryOfBirth + ", ";

  const isnull = goal.utils.isNull;

  if(get !== null) {
    birth += `${get[0].replace(/(-)/g, " | ")}`;
  }
  else birth += "-"


  return (
    <li className="collection-item">
      <table>

        <tbody className="player-info">
          <tr>
            <td className="head material-icons">person</td>
            <td className="value">{p.name}</td>
          </tr>
          <tr>
            <td className="head material-icons">emoji_flags</td>
            <td className="value">
              {p.position === null || p.position === ""? "-" : p.position}
            </td>
          </tr>
          <tr>
            <td className="head material-icons">cake</td>
            <td className="value">
              {birth}
            </td>
          </tr>
        </tbody>

      </table>
    </li>
  )
}

export function TeamCollection(props: {team: FBOrg.Team}) {
  let [remove, setRemove] = useState(false);
  let {team} = props;

  useEffect(function() {
    goal.on("removeTeam", fns.collectionRemove)
    return () => {
      goal.off("removeTeam", fns.collectionRemove)
    }
  });

  const
    crest = goal.Media.crestNull(team),
    selectNone: React.CSSProperties = { userSelect: "none" },
    fns = {
      removeClick(e: React.MouseEvent<HTMLAnchorElement>) {
        e.stopPropagation();
        goal.emit("removeTeam", team);
      },
      collectionRemove(e: FBOrg.Team) {
        if(e.id === team.id) setRemove(true);
      }
    };

  return (
    <div
      className={"collection-item avatar scale-transition" + (remove? " scale-out": "")}
      onClick={() => {goal.emit("modal.Open", team)}}
    >

      <img src={crest} className="circle image" style={selectNone} />
      <span className="title" style={selectNone}>{team.shortName}</span>

      <p>
        <a href={team.website} target="_blank" onClick={(e) => e.stopPropagation()}>
          {team.website}
        </a>
        <br/>
        <span className="dummy-text" style={selectNone}>
          Click this tab to see more infos.
        </span>
      </p>

      <a
        href="#" className="secondary-content"
        onClick={fns.removeClick}
      >
        <i className="material-icons">{goal.icons.remove}</i>
      </a>

    </div>
  )
}

export function TeamCard(props: {team: FBOrg.Team, liked: boolean}) {
  let [liked, setLiked] = useState(props.liked);

  let fn = {
    cardLike(e: FBOrg.Team) {
      if(e.id === props.team.id) setLiked(true)
    },
    cardUnLike(e: FBOrg.Team) {
      if(e.id === props.team.id) setLiked(false)
    },
    likeClick(e: React.MouseEvent<HTMLAnchorElement>) {
      e.preventDefault();
      let t = liked? "removeTeam" : "addTeam";
      goal.emit(t, props.team);
    }
  }

  useEffect(function() {
    goal
    .on("addTeam", fn.cardLike)
    .on("removeTeam", fn.cardUnLike);

    return function() {
      goal
      .off("addTeam", fn.cardLike)
      .off("removeTeam", fn.cardUnLike);
    }
  });

  const
  {team} = props,
  {icons} = goal,
  crest = goal.Media.crestNull(team);

  return (
    <div className="r-card">

      <div className="logo">
        <img src={crest} alt={team.shortName + "logo."} />
        <span className="r-card-title">{team.shortName}</span>
      </div>

      <div className="content">
        <div>
          <span className="head">Club Name:</span>
          <span className="value">{team.name}</span>
        </div>

        <div>
          <span className="head">Place:</span>
          <span className="value">{team.area.name},</span>
          <span className="value">{team.address}</span>
        </div>

        <div>
          <span className="head">Website:</span>
          <a className="value" href={team.website}>{team.website}</a>
        </div>
      </div>
      <div className="link">
        <a
          className="card-btn right waves-effect waves-light"
          idb-do="add"
          href="#"
          onClick={fn.likeClick}
        >
          <i className="material-icons">{liked? icons.like : icons.unlike}</i>
        </a>
      </div>
    </div>
  )
}

export function SubsBtn(props: {type: string}) {
  const {type} = props;
  const suffix = type === "endpoint"? "link" : "key";
  const Upper = type[0].toUpperCase() + type.slice(1);

  const fn = {
    copyBtn(e: React.MouseEvent<HTMLAnchorElement, MouseEvent>) {
      if(goal.utils.isUndefined(goal.Subs)) {
        let t = `${Upper} keys is not yet registered`;
        console.warn(t);
        M.toast({
          html: t,
          displayLength: 1500
        })
        return;
      }
      let text = Upper + ` key: Copied to Clipboard!`;

      navigator.clipboard
      .writeText(goal.Subs[type])
      .then( () => {
        M.toast({
          html: text,
          displayLength: 1500
        });
      })
      .catch(err => { throw err })
    }
  }

  let btn: HTMLAnchorElement
  let tooltip: M.Tooltip;

  useEffect(function() {
    tooltip = M.Tooltip.init(btn, {
      html: `copy ${type} ${suffix}`,
      position: "top"
    })

    return function() {
      tooltip.destroy();
    };
  })

  return (
    <td className="head">
      <a
        className="btn waves-effect waves-light"
        onClick={fn.copyBtn}
        ref={(e) => {btn = e} }
      >
        {`${Upper} ${suffix}`}
        <i className="material-icons">
          content_copy
        </i>
      </a>
    </td>
  )
}

interface StatusTabProps {
  titleText: string;
  state: boolean;
  stateText?: {
    onTrue: string;
    onFalse: string;
  }
}
export function StatusTab(props: StatusTabProps) {
  let {titleText, state} = props;

  let trueText = "ready";
  let falseText = "pending";

  if(props.stateText) {
    let t = props.stateText;
    trueText = t.onTrue;
    falseText = t.onFalse;
  }

  return (
    <tr className={state? "online" : "offline"}>
      <td className="head">{titleText}</td>
      <td className="value">
        {state? trueText : falseText}
      </td>
    </tr>
  )
}