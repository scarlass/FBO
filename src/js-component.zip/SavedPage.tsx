import React, { useState } from "react";
import {TeamCollection} from "./Utils"

interface SavedPageProps {
  show: string;
}
interface SavedPageState {
  collection: JSX.Element[]
}

export default class SavedPage extends React.Component<SavedPageProps, SavedPageState> {
  state: SavedPageState = {
    collection: []
  }

  componentDidMount() {
    let clc: JSX.Element[] = [];
    goal
    .on("addTeam", (e) => {
      clc.push(<TeamCollection key={e.id} team={e}/>);
      this.setState({ collection: clc });
    })
    .on("removeTeam", (e) => {
      let idx = clc.findIndex(i => (+i.key) === e.id);
      if(idx === -1) return;

      setTimeout(() => {
        clc.splice(idx, 1);
        this.setState({ collection: clc })
      }, 350);
    })
    .request("trax", async (db) => {
      let all = await db.getAll();
      for(let k of all) clc.push(<TeamCollection key={k.id} team={k}/>);
      this.setState({ collection: clc });
    });
  }

  render() {
    let style = { display: "none" }
    return (
      <div
        id="page-root"
        className="row"
        style={this.props.show.toLowerCase() === "saved" ? null : style}
        {...{saved: "", } }
      >
        <div className="saves col s12">
          <div id="saved-clc" className="collection">
            {this.state.collection}
          </div>
        </div>
      </div>
    )
  }
}
