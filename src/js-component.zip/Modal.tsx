import React, { useState } from "react";
import {SquadCard} from "./Utils";

interface ModalState {
  team: FBOrg.Team;
  matches: FBOrg.Match;
}

interface elTabs {
  main: HTMLUListElement;
  bMatch: HTMLAnchorElement;
}
interface elModal {
  main: HTMLDivElement;
  match: HTMLDivElement;
  info: HTMLDivElement
}

export default class Modal extends React.Component<{}, ModalState> {
  state: ModalState = {
    team: undefined,
    matches: undefined
  }

  elModal: elModal = {
    main: undefined,
    match: undefined,
    info: undefined
  }

  elTabs: elTabs = {
    main: undefined,
    bMatch: undefined
  }

  componentDidMount() {
    this.setState
    goal.Modal = new M.Modal(this.elModal.main) as any;

    Object.defineProperties(goal.Modal, {
      tabs: {
        value: new M.Tabs(this.elTabs.main, { duration: 100}),
        enumerable: true,
        writable: false
      },
      tabInfo: {
        value: this.elModal.info,
        writable: false,
        enumerable: true
      },
      destroy: {
        value: function() {},
        writable: false
      }
    });

    goal
    .on("modal.Open", (e) => {
      goal.Modal.open();
      goal.request("team", e.id)
      .then(res => res.json())
      .then((res: FBOrg.Team) => {
        this.setState({ team: res });
        goal.request("trax", "readwrite", function(db) {
          db.put(res, e.id)
        });
        return res;
      })
      .catch(err => { throw err });
    })
    .Media.addQuery({
      at: 720,
      type: "max",
      onMatch() {
        goal.Modal.options.dismissible = false;
      },
      onMissmatch() {
        goal.Modal.options.dismissible = true
      }
    })
  }

  render() {
    const eTeam = typeof this.state.team !== "undefined";
    const team = this.state.team;

    return (
      <div id="team-info" className="modal" ref={(el) => {this.elModal.main = el}}>

        <div className="modal-content row">

          <div className="btns col s12">
            <img
              className="team-logo left"
              src={eTeam? goal.Media.crestNull(team) : null}
              alt={eTeam? team.shortName + " Logo." : null} />
            <span className="team-name left">{eTeam? team.name : ""}</span>

            <a href="#" className="close" onClick={() => {goal.Modal.close()}}>
              <i className="material-icons">close</i>
            </a>
          </div>

          <div className="r-tabs col s12 row">
            <ul id="m-tabs" className="tabs" ref={(el) => {this.elTabs.main = el}}>

              <li className="tab col s12">
                <a
                  className="left"
                  href="#t-infos"
                >
                  Current Squads
                </a>
              </li>

            </ul>
          </div>

          <div id="t-infos" className="content col s12" ref={(el) => {this.elModal.info = el}}>
            <ul className="collection info">
              {eTeam && team.squad? team.squad.map( s => {
                  return <SquadCard Player={s} key={s.id} />
                }) : null}
            </ul>
          </div>

        </div>
      </div>
    )
  }
};