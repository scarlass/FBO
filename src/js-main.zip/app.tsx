import React, {useState} from "react";
import ReactDOM from "react-dom";

import HomePage from "./component/HomePage";
import SearchPage from "./component/SearchPage";
import SavedPage from "./component/SavedPage";
import Modal from "./component/Modal";
import { IndexNavBtn } from "./component/Utils";

import "materialize-css";


interface AppState {
  page: string;
  status: {
    cn: boolean;
    rs: boolean;
  }
}

class App extends React.Component<{}, AppState> {
  constructor(p = {}) {
    super(p);

    this.state = {
      page: "home",
      status: {
        cn: goal.Status.connection,
        rs: goal.Status.readyState
      }
    }
  }

  componentDidMount() {
    const load = goal.loading;

    goal
    .on("ready", function(e) {
      load.show()
    })
    .on("page.changed", (e) => { this.setState({page: e}) })
    .on("statusChanged", (e) => {
      let {cn, rs} = this.state.status
      let def = e.type === "cn"

      this.setState({
        status: {
          cn: def? e.newV : cn,
          rs: def? rs : e.newV
        }
      });
    });

    if(!goal.Status.readyState) {
      load.show(true).text("Initialize . . .");
    }
  }

  render() {
    let {status, page} = this.state;

    return (
      <div id="app">

        <header>

          <ul className="sidenav sidenav-fixed">
            <IndexNavBtn page="home" selected={page}/>
            <IndexNavBtn page="search" selected={page}/>
            <IndexNavBtn page="saved" selected={page}/>
          </ul>

        </header>

        <main>

          <div
            id="loading-ctn"
            className="stop hide"
            ref={(e) => goal.setElems({ loading: e })}
          >
            <div className="loading-icon"></div>
            <div className="loading-text"></div>
          </div>

          <div id="page-load">
              <HomePage status={status} show={page}/>
              <SearchPage cn={status.cn} show={page}/>
              <SavedPage show={page} />
          </div>

          <div className="background"></div>

        </main>

        <Modal />

      </div>
    )
  }
};


ReactDOM.render(
  <App />,
  document.getElementById("root")
);

