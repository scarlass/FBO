import {reqs as req, utils, fetch} from "./mix";
import * as sw from "./registerSW";
import {EventEmitter} from "events";


if(!utils.isUndefined(goalSW) && goalSW.runRegist) {
  sw.registerSW()
  .then( res => {
    sw.registerSubs({
      logSubKeys: goalSW.logging
    });
  });
}


const {
  isArray: isArr,
  isObject: isObj,
  isUndefined: isUnd,
  isNull,
  isString: isStr,
  isNumber: isNum,
  isRegex: isRex
} = utils;

let AreaReady = false
fetch()
.then(res => res.json())
.then((res) => {
  req.Trax(
    {
      storeName: "area",
      mode: "readwrite"
    },
    async function(db) {
      for(let k of res.areas) {
        const check = await db.get(k.id);
        if(isUnd(check)) db.put(k, k.id);
      }
    }
  );

  return void 0;
})
.then(() => {
  GO.Status.connection = true;
  AreaReady = true;
})
.catch(err => {
  GO.Status.connection = false;
  AreaReady = true;

  switch(typeof err) {
    case "string": {
      throw Error(err);
    }
    case "object": {
      console.error(err);
      throw Error("failed to fetch data");
    }
    default: {}
  }
})


type RequestType = "team" | "area" | "trax" | "competitions";

// ############################################################
const
State = {
  cn: false,
  rs: false
},
Media = {
  icons: {
    home: "home",
    search: "search",
    saved: "folder_special",
    like: "star",
    unlike: "star_border",
    remove: "remove_circle"
  }
},
Els: G.Elements = {};

const GO = new (
class Goal extends EventEmitter implements globalThis.Goal {
  Areas?: { [id: string]: string };
  Modal?: G.Modal;

  get utils(): G.Utility { return utils }
  get icons(): G.Icons { return Media.icons };
  get loading(): G.Loading {
    let load = Els.loading;
    let $text = load.querySelector(".loading-text");

    $text.innerHTML = "Loading . . .";

    return {
      show(show = false) {
        if(show) {
          load.classList.remove("hide");
          load.classList.remove("stop");
        }
        else {
          load.classList.add("hide");
          load.classList.add("stop");
        }
        return this
      },
      text(text: string) {
        $text.innerHTML = text;
        return this
      }
    }
  }

  Status: G.Status = (() => {
    const t = this;
    return {
      set connection(val) {
        const fix = State.cn
        t.emit("statusChanged", {
          type: "cn",
          newV: (State.rs = val),
          oldV: fix
        });
      },
      get connection() { return State.rs },
      set readyState(val) {
        const fix = State.rs
        t.emit("statusChanged", {
          type: "rs",
          newV: (State.rs = val),
          oldV: fix
        });
      },
      get readyState() { return State.rs }
    }
  })();

  Media: G.Media = (() => {
    const t = this;
    return {
      crestNull(team: FBOrg.Team) {
        let nullEmp = team.crestUrl === "" || team.crestUrl === null;
        return nullEmp? "./assets/logo_blank.webp" : team.crestUrl;
      },

      addQuery(...trg: G.Media.QueryOptions[]) {
        for(let obj of trg) {
          let
            at = isStr(obj.at)? obj.at : obj.at + "px",
            scr = window.matchMedia(`(${obj.type}-width:${at})`),
            noMatch = obj.onMissmatch,
            atMatch = obj.onMatch;

          function change() {
            if(scr.matches) {
              if(isUnd(atMatch)) return;
              atMatch(scr);
            }
            else {
              if(isUnd(noMatch)) return;
              noMatch(scr);
            }
          }

          scr.addEventListener("change", change);
          change();
        }
        return this;
      }
    }
  })();

  constructor() {
    super();

    let t = setInterval(() => {
      if(AreaReady) {
        this.Status.readyState = true;
        this.emit("ready");
        this._init();
        clearInterval(t);
      }
    }, 100);

  }

  attachError(el: HTMLElement, opt: G.AttachErrorOptions = {}) {
    let text = "Connection failed.";

    if(opt.text) {
      if(opt.extendDefaultText) {
        text += opt.text
      }
      else {
        text = opt.text
      }
    }

    if(opt.remove) {
      el.classList.remove("error");
      el.innerHTML = "";
      if(opt.hasHideClass) el.classList.add("hide")
    }
    else {
      el.classList.add("error");
      el.innerHTML = `
      <div class="err-ctn">
        <h6 style="user-select: none;">${text}</h6>
      </div>`;
      if(opt.hasHideClass) el.classList.remove("hide")
    }

  }
  attachEmpty(el: HTMLElement, opt: G.AttachMiscOptions = {}) {
    let text = "No Data"

    if(opt.text) {
      if(opt.extendDefaultText) {
        text += opt.text
      }
      else {
        text = opt.text
      }
    }

    if(opt.remove) {
      el.classList.remove("empty-data");
      el.innerHTML = "";
    }
    else {
      el.classList.add("empty-data");
      el.innerHTML = `
      <div class="emp-ctn">
        <h6>${text}.</h6>
      </div>`;
    }
  }

  request(reqType: RequestType, arg2?: any, arg3?: any, arg4?: any) {
    let loadText = "";
    let load = this.loading;

    if(reqType === "area" || reqType === "team") {
      let state = false;
      if(typeof arg2 === "object" && arg2.showLoading) {
        state = arg2.showLoading as boolean;
      }
      else if(typeof arg3 === "object" && arg3.showLoading) {
        state = arg3.showLoading as boolean;
      }
      load.show(state);
    }

    switch(reqType) {
      case "team": {
        try {
          return req.Team(arg2, arg3);
        }
        catch (err) {
          this.Status.connection = false;
          throw err;
        }
      }
      case "area": {
        let f = (arg2 || {}) as G.RequestAreaOptions;

        if(isArr(f.area)) {
          let d = f.area.map((i) => this.Areas[i]);
          loadText = d.join(", ");
          load.text("Loading: " + loadText);
        }
        else if(isNum(f.area)) {
          loadText += this.Areas[f.area];
          load.text("Loading: " + loadText + " . . .");
        }

        try {
          return req.Area(arg2);
        }
        catch (err) {
          this.Status.connection = false;
          throw err;
        }
      }
      case "trax": {
        req.Trax(arg2, arg3);
        break;
      }
      case "competitions": {

        try {
          return req.Competitions(
            arg2,
            isNum(arg2) ? { searchFor: arg3, filter: arg4 } : undefined
          );
        }
        catch (err) {
          this.Status.connection = false;
          throw typeof (err) === "object" ? err.message : err;
        }
      }
      default: {}
    }
  }

  setElems(store: G.Elements) {
    if(typeof store !== "object") return;
    for(let k in store)Els[k] = store[k];
  }
  getElems(namedEl: string) { return Els[namedEl] }

  private _setReadonly() {
    for(let k in this) {
      if(/^(_)/.test(k)) {
        Object.defineProperty(this, k, { enumerable: false });
      }
    };
    Object.defineProperties(this, {
      Status: {writable: false},
    });
  };
  private _init() {
    this._setReadonly();
    window.addEventListener("online", (e) => this.Status.connection = true);
    window.addEventListener("offline", (e) => this.Status.connection = false);

    let on = ["addTeam", "removeTeam"];
    for(let i of on) {
      this.on(i, (e: FBOrg.Team) => {
        req.Trax("readwrite", async (db) => {
          let has = await db.get(e.id);

          if(i === "addTeam") {
            if(isUnd(has)) {
              e.crestUrl = this.Media.crestNull(e);
              db.add(e, e.id);
              this.emit("notif.AddedTeam", e);
            }
          }
          else db.delete(e.id);
        });
      });
    }

    this
    .on("notif.AddedTeam", (e: FBOrg.Team) => {
      if(Notification.permission === "granted") {
        navigator.serviceWorker.ready.then(res => {
          res.showNotification("Added to Saved List:", {
            requireInteraction: false,
            body: e.name,
            badge: "/assets/logo512.png",
          });
        });
      }
    });
  }

});


window.goal = GO.setMaxListeners(100);